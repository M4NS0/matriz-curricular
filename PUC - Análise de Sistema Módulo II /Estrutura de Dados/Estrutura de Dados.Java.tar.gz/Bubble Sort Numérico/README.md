   
    Nome            : Busca por Bubble Sort Numérico
    Livro           : Estrutura de Dados e Técnicas de Programação
    Autores         : Bianchi, Dilermando, Nakamiti, Freitas, Xastre
    Página          : 108
    Descrição       : Técnica de Bubble Sort  empregado a Vetor de Números 