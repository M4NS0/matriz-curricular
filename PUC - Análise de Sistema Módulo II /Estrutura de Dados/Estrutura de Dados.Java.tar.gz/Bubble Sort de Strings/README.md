# Estudo
| | |
| ------ | ------ |
| Livro |   Estrutura de Dados e Técnicas de Programação |
| Título | Busca por Bubble Sort de Strings |
| Autor | Bianchi, Dilermando, Nakamiti, Freitas, Xastre |
| Página | 108 |
| Matéria | Estrutura de Dados |
| Disponível | www.tutorialspoint.com/perform-bubble-sort-on-strings-in-java |
|Descrição | Baseado no Exemplo do livro, a técnica  de  Bubble  Sort empregado a Vetor de Strings exemplo de metodo compareTo na linha 24 da classe BubbleSort
  