
    Nome            : Busca Binária Recursiva em Vetor de Números
    Livro           : Estrutura de Dados e Técnicas de Programação
    Autores         : Bianchi, Dilermando, Nakamiti, Freitas, Xastre
    Página          : 74
    Descrição       : Busca Binária Recursiva em vetor de números 
                      Algorítmo de Busca Binária Recursiva em vetor 
                      com tempo de processamento MENOR que Busca Binária 