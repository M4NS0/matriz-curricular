 
    Nome                    : Busca Binária em Vetor de Strings
    Baseado no Livro        : Estrutura de Dados e Técnicas de Programação
    Autores                 : Bianchi, Dilermando, Nakamiti, Freitas, Xastre
    Descrição               : Busca Binária em vetor de String 
                              Algorítmo de Busca Binária em vetor com tempo 
                              de processamento MENOR que Busca Sequencial