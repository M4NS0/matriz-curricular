   
    Nome            : Busca Binária em Vetor de Números
    Livro           : Estrutura de Dados e Técnicas de Programação
    Autores         : Bianchi, Dilermando, Nakamiti, Freitas, Xastre
    Página          : 108
    Descrição       : Busca Binária em vetor de números 
                      Algorítmo de Busca Binária em vetor com tempo 
                      de processamento MENOR que Busca Sequencial