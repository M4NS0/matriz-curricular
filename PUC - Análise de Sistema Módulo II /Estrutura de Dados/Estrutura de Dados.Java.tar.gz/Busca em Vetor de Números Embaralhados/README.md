   
    Nome            : Busca Sequencial
    Livro           : Estrutura de Dados e Técnicas de Programação
    Autores         : Bianchi, Dilermando, Nakamiti, Freitas, Xastre
    Página          : 73
    Descrição       : Busca em vetor de números embaralhados
                      Algorítmo de Busca em vetor Embaralhado com tempo 
                      de processamento MAIOR que vetor Ordenado