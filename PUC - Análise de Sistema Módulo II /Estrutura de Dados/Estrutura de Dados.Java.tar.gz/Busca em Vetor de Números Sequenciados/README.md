   
    Nome            : Busca Sequencial
    Livro           : Estrutura de Dados e Técnicas de Programação
    Autores         : Bianchi, Dilermando, Nakamiti, Freitas, Xastre
    Página          : 73
    Descrição       : Busca em vetor de números Ordenados
                      Algorítmo de Busca em vetor Ordenado com tempo 
                      de processamento MENOR que vetor Embaralhado