   
    Nome            : Busca Sequencial
    Baseado em      : Estrutura de Dados e Técnicas de Programação
    Autores         : Bianchi, Dilermando, Nakamiti, Freitas, Xastre
    Descrição       : Busca em vetor de Strings embaralhadas
                      Algorítmo de Busca em vetor Ordenado com tempo 
                      de processamento MENOR que vetor Embaralhadoo