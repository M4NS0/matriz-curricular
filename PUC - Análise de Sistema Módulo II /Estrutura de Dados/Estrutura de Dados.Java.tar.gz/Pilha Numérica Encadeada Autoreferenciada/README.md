   
    Nome            : Pilha Numérica Encadeada/Autoreferenciada
    Baseado em      : Estrutura de Dados em Java
    Autores         : Luzzardi
    Página          : 62-64
    Descrição       : O programa abaixo demonstra a inclusão, exclusão
                      e consulta em uma Pilha alocada dinamicamente