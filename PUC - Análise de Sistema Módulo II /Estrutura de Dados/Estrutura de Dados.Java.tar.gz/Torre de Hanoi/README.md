   
    Nome            : Torre de Hanoi
    Baseado em      : Estrutura de Dados e Técnicas de Programação
    Autores         : Bianchi, Dilermando, Nakamiti, Freitas, Xastre
    Página          : 53
    Descrição       : Resolve o quebra-cabeça da Torre de Hanoi
    