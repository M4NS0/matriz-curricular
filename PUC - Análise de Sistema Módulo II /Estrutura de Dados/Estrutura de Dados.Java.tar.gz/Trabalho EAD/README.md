	
	Instituição     : Pontifícia Universidade Católica de Goiás
	Departamento    : Escola de Ciências Exatas e da Computação
	Curso           : Análise e Desenvolvimento de Sistemas
	Matéria         : Estrutura de Dados
	Professor       : José Olímpio Ferreira
	Período         : Segundo
	Avaliação       : Trabalho EAD / N2
	Título          : Agenda em Lista Encadeada e Ordenada
	Autor           : Bruno Camargo Manso
	Descrição       : O presente trabalho tem o objetivo de desenvolver uma agenda cujos 
	                  dados são guardados em uma lista simplesmente encadeada.  A  lista 
	                  deve ser ordenada seguindo a lógica  de  ordenação  de  uma  lista 
	                  encadeada. O programa deverá, além de mostrar os  dados  de  forma 
	                  ordenada (crescente e decrescente) para o usuário,  salvar  em  um 
	                  arquivo de texto,  ou  backup,  para  que  este  seja  devidamente 
	                  reaproveitado na próxima  vez  que  o  programa  for  executado. O 
	                  trabalho a seguir contém códigos em Java tanto do programa em modo 
	                  texto (terminal) quanto em interface gráfica (Jframe).