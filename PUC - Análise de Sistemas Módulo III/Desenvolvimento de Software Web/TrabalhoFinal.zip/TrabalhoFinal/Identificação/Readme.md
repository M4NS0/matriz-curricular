	
	Instituição     : Pontifícia Universidade Católica de Goiás
	Departamento    : Escola de Ciências Exatas e da Computação
	Curso           : Análise e Desenvolvimento de Sistemas
	Matéria         : Desenvolvimento de Software Web 
    Sigla           : CMP-1491
	Professor       : Vicente Paulo Camargo
	Período         : Terceiro
    Ano             : 2020
	Avaliação       : Trabalho EAD / N2
	Título          : Projeto Linha de Ônibus
	Descrição       : Crud de um Sistema de Linhas de Ônibus em plataforma web. 
	Tecnologias     : Html, Css, Json, Jquery, Ajax, Java, JavaScript com CRUD completo em Banco de dados SQL. Servidores SQL e TomCat
	Autores         : Bruno Camargo Manso - 20201012000590
                      João Victor Cardoso - 20201012000230

