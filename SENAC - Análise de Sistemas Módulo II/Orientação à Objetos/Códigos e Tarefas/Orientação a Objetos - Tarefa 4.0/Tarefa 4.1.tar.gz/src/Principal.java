import java.util.Date;

public class Principal {
	public static void main(String[] args) {
		
		Medicamento medicamento1 = new Medicamento();
		medicamento1.setNome("Canabidiol");
		medicamento1.setId(696969);
		medicamento1.setPrincipioAtivo("CDB");
		medicamento1.setUnd("não declarado");
		medicamento1.setQuantidadeEstoque(55);
		
		Date data = new Date();    // pega a data de hoje 
		medicamento1.setDataValidade(data);
		
		System.out.println(	"\n============================================\n" +
							"\n      Nome: " + medicamento1.getNome() +
							"\n        ID: " + medicamento1.getId() +
							"\n       P.A: " + medicamento1.getPrincipioAtivo() + 
							"\n       UND: " + medicamento1.getUnd() + 
							"\n   Estoque: " + medicamento1.getQuantidadeEstoque() + 
							"\n  Validade: " + medicamento1.getDataValidade()+
							"\n");
		
		
		Medicamento medicamento2 = new Medicamento();
		medicamento2.setNome("Brunol");
		medicamento2.setId(6666666);
		medicamento2.setPrincipioAtivo("THC");
		medicamento2.setUnd("não declarado");
		medicamento2.setQuantidadeEstoque(69);
		
		Date data2 = new Date();    // pega a data de hoje 
		medicamento2.setDataValidade(data2);
		
		System.out.println(	"\n============================================\n" +
							"\n      Nome: " + medicamento2.getNome() +
							"\n        ID: " + medicamento2.getId() +
							"\n       P.A: " + medicamento2.getPrincipioAtivo() + 
							"\n       UND: " + medicamento2.getUnd() + 
							"\n   Estoque: " + medicamento2.getQuantidadeEstoque() + 
							"\n  Validade: " + medicamento2.getDataValidade()+
							"\n");
		
	}
}
