package v2;

public class Assistente extends Funcionario {

	public Assistente() {
		
	}
	public Assistente(int m, String n, String d) {
		this.matricula = m;
		this.nome = n;
		this.departamento = d;
	}
	
}
