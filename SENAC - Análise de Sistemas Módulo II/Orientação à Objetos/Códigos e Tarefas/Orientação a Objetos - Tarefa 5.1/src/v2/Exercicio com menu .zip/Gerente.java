package v2;

public class Gerente extends Funcionario {

	}

