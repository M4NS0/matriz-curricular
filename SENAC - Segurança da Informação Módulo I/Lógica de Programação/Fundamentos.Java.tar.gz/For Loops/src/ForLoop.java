// For Loop

public class ForLoop {
	public static void main(String[] args) {

		// i += 1 ou i ++ ou i = i + 1
		for (int i = 0; i < 5; i += 1) {

			// printf changes the method
			// %d will place the value of i after comma

			System.out.printf("The value of i is: %d \n", i);
		}
	}
}
