import ocean.Fish;
import ocean.flora.Seaweed;
import ocean.flora.Sponge;

// import ocean.Fish;
// import ocean.Seaweed;
// import ocean.*

// right clicking over this line on Source >> Organize imports
// or the same as control shift 'O' will automatically add the imports needed.

public class App {
	public static void main(String[] args) {
		Fish fish = new Fish();
		Seaweed weed = new Seaweed();
	}
}
