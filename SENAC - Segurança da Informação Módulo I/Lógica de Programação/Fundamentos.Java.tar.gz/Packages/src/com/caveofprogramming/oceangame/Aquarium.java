package com.caveofprogramming.oceangame;
// if u want to reveal to certain domain it should be reversed as above
public class Aquarium {

}
