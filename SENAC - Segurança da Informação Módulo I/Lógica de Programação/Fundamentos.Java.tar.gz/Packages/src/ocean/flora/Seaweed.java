package ocean.flora;

public class Seaweed {

}
