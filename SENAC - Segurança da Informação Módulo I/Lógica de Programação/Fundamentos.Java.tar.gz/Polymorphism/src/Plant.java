
public class Plant {	// parent class Plant
	// doing a growth method
	public void grow () {
		System.out.println("Plant growing....");
		
	}
}
