// Strings

public class Strings {

	public static void main(String[] args) {  // main class to start the program
		
		int myInt = 7;
				
		// string is a class
	  	// string is a type of object
		
		String text = "Hello"; 	
		String blank = "";
		String name = "Bob";
		String greeting = text + blank + name;
		System.out.println(greeting);
		System.out.println("Hello" + blank + "Bob");
		System.out.println("My integer is: " + myInt);
			

	}

}
