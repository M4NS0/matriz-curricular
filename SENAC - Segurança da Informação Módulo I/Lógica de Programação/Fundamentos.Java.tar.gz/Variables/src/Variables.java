// Variables
public class Variables {

	public static void main(String[] args) {
		int myInt = 33; //32 Bytes
		short myShort = 877;
		long myLong = 909088; //64 Bytes
		
		double myDouble = 7.65656;
		float myFloat = 324.7f;
		
		char myChar = 'y';
		boolean myBoolean = true; // or false
		
		byte myByte = 127; //holds 8 Bytes	
		
		System.out.println(myInt);
		System.out.println(myShort);
		System.out.println(myLong);
		System.out.println(myDouble);
		System.out.println(myFloat);
		System.out.println(myChar);
		System.out.println(myBoolean);
		System.out.println(myByte);

				
				

	}

}
