
public class Exercicio03 {

	public static void main(String[] args) {

		int numero = 100;

		while (numero >= 1) {
			if ((numero % 2) == 0) {
				System.out.print(numero + " - ");
			}
			numero--;
		}
	}
}
