print("O número 3025 possui a seguinte característica:"
      +"\n30 + 25 = 55"
      +"\n55² = 3025"
      +"\nDado um número de 4 dígitos calcule e escreva se ele possui ou não esta característica.")

x = int(input("\nInsira um número qualquer: "))

if x      
