print("\nLer o mês e o ano de uma data e exibir o número de dias da mesma.")

mes = int(input("Escreva qual mês (numérico): "))
ano = int(input("Escreva qual é o ano atual: "))


