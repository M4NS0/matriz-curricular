print("\nNúmeros palíndromos ou capicuas são aqueles que escritos da direita para esquerda"
      + "\nou da esquerda para direita tem o mesmo valor. Exemplo 929, 44, 97379."
      + "\nesse algoritmo  analisa se dado um número de 5 dígitos, calcula e escreve se este é ou não palíndromo.\n")

numero = int(input("Insira um número de 5 digitos: "))

