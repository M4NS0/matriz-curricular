print("Desenvolver um algoritmo que leia os coeficientes (A,B e C) de uma equação do segundo grau"
      + "\n(Ax² + Bx + C =0) e que calcule suas raízes. O algoritmo deve mostrar, quando possível,"
      + "\no valor das raízes calculadas e a classificação das mesmas:"
      + "\n“RAÍZES, IMAGINÁRIAS”, “RAIZ ÚNICA” ou “RAÍZES DISTINTAS”.")


