print("esse programa cadastra dados e os imprime")
nome = input("Digite seu nome: ")
endereco = input("Digite o endereço: ")
email = input("Digite seu e-mail: ")
fone = input("Digite seu telefone: ")

print("O nome é {} .Residente em: {}. Seu endereço de e-mail é {} .E seu telefone é: {}".format(nome, endereco, email, fone))