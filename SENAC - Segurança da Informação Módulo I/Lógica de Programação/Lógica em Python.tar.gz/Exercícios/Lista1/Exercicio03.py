print("Insira a base e a altura para cálculo da area do triângulo")

b = int(input("Digite a base do triângulo: "))
h = int(input("Digite a altura do triângulo: "))
a = b * h
print("A área desse triângulo  é: {}".format(a))