print("Cadastre o peso de 4 pessoas e imprima a média dos pesos")
p1 = float(input("Digite o peso da primeira pessoa: "))
p2 = float(input("Digite o peso da segunda pessoa: "))
p3 = float(input("Digite o peso da terceira pessoa: "))
p4 = float(input("Digite o peso da quarta pessoa: "))

m = ( p1 + p2 + p3 + p4 ) / 4
print("A media de peso das 4 pessoas é: {}".format(m))
