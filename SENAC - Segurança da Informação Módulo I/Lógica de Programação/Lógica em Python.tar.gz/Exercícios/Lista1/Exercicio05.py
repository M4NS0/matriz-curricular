print("Solicitar o usuário que digite uma palavra e imprima: Qual o primeiro caractere da palavra e quantos caracteres ela possui.")
palavra = str(input("Escreva uma palavra aleatória: "))
palavra = palavra[0]

print("A primeira letra da palavra digitada é {}".format(palavra))

