print("Sabendo que uma milha marítima equivale a um mil, oitocentos e cinqüenta e dois metros e que um quilômetro possui mil metros, fazer um programa para converter milhas marítimas em quilômetros. ")
numero = float(input("Digite a qualntidade de Milhas: "))
milhas = 1852
km = 1000
conver = numero * milhas

print("O valor convertido de KM para milhas é igual a {}".format(conver))
