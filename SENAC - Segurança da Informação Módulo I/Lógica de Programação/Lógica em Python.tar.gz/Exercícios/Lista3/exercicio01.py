print("\nEste programa tem objetivo de ler dois números e \n\tverificar qual o menor e qual o maior")

n1 = float(input("\nInforme o primeiro numero: "))
n2 = float(input("\nInforme o segundo numero: "))

if n1>n2:
    print("\nO primeiro numero digitado é MAIOR que o segundo.")


elif n1<n2:
    print("\nO primeiro numero digitado é MENOR que o segundo.")

