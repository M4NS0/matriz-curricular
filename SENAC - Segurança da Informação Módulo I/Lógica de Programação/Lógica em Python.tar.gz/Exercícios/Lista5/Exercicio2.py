cont: float = 1
soma: float = 0

for cont in range(1, 20):
    soma = soma + (1/cont)
print(soma)