contagem = 0

num = int(input("Insira um número: "))

while (num != contagem):

    if num >= 0:
        num = int(input("Insira um número: "))
    elif num < 0 :
        num = int(input("Invalido por ser negativo, insira outro q seja positivo: "))
