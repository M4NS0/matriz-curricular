for contador in range(1,10):
    resultado = contador * 5

    print("5 x {} = {}".format(contador,resultado))
    
