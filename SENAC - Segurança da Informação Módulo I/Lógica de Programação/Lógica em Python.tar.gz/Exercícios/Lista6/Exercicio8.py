soma = 0

for cont in range(1,100):
    cont += 1
    soma = soma + cont

    print(soma)