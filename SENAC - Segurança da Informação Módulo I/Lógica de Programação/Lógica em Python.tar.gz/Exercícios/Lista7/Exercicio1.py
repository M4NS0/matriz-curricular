num = int(input("Insira um numero: "))
for cont in range (1,num,1):
    if (cont % 2) == 0:
        print(cont)