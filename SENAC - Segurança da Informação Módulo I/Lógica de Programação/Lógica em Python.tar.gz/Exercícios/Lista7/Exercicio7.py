for num in range (1,500,1):
    if (num % 5) == 0:
        print(num)